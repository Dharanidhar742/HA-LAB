package com.example.intentact;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondIntent extends AppCompatActivity {

    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_intent);
        Intent intent=getIntent();
        result = (TextView) findViewById(R.id.txt1);
        String s=intent.getStringExtra("value");
        result.setText(s);
    }
}